import PropTypes from "prop-types";
function UploadForm({
 selectedFile,
 onFileSelect,
 onUpload,
 isUploading,
 showAlert
 }) {
 function validateFile(file) {
 if (!file) {
 showAlert("warning", "No file selected.");
 return false;
 }
const isXlsx =
  file.name.toLowerCase().endsWith(".xlsx") ||
  file.type ===
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

if (!isXlsx) {
  showAlert("error", "Only .xlsx Excel files are allowed.");
  return false;
}

const maxSizeBytes = 2 * 1024 * 1024; // 2 MB
if (file.size > maxSizeBytes) {
  showAlert(
    "error",
    "File is too large. Please upload a file smaller than 2 MB."
  );
  return false;
}

return true;

}
function handleFileChange(event) {
 const file = event.target.files && event.target.files[0];
if (!file) {
  onFileSelect(null);
  return;
}

if (!validateFile(file)) {
  onFileSelect(null);
  event.target.value = "";
  return;
}

onFileSelect(file);
showAlert("success", `Selected file: ${file.name}`);

}
function handleUploadClick() {
 if (!selectedFile) {
 showAlert("warning", "Please select a valid Excel file first.");
 return;
 }
 onUpload();
 }
return (

 Upload Excel and view API response
 <div className="upload-row">
    <label className="btn-file" htmlFor="file-input">
      Choose file
    </label>
    <input
      id="file-input"
      type="file"
      className="file-input-hidden"
      accept=".xlsx"
      onChange={handleFileChange}
    />

    <div className="file-label-text">
      {selectedFile ? selectedFile.name : "No file selected yet"}
    </div>

    <button
      type="button"
      className="btn-upload"
      onClick={handleUploadClick}
      disabled={isUploading}
    >
      {isUploading ? "Uploading..." : "Upload"}
    </button>
  </div>

  <p className="file-selected-info">
    Selected file:{" "}
    <span className="file-selected-name">
      {selectedFile ? selectedFile.name : "None"}
    </span>
  </p>
</div>

);
 }
UploadForm.propTypes = {
 selectedFile: PropTypes.any,
 onFileSelect: PropTypes.func.isRequired,
 onUpload: PropTypes.func.isRequired,
 isUploading: PropTypes.bool,
 showAlert: PropTypes.func.isRequired
 };
export default UploadForm;
