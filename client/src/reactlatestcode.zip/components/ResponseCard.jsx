import { useState } from "react";
 import PropTypes from "prop-types";
 import { generateUploadSummary } from "../utils/aiSummary";
function safeNumber(value) {
 if (typeof value === "number") return value;
 if (typeof value === "string" && value.trim() !== "") {
 const n = Number(value);
 return Number.isNaN(n) ? 0 : n;
 }
 return 0;
 }
function ResponseCard({ result }) {
 const [aiText, setAiText] = useState("");
 const [aiLoading, setAiLoading] = useState(false);
 const [aiError, setAiError] = useState("");
if (!result) {
 return (

 Upload a file to see the summary here.

 );
 }
const fileName =
 result.fileName ||
 result.filename ||
 result.meta?.fileName ||
 "Unknown file";
const totalRows =
 safeNumber(result.totalRows ?? result.meta?.totalRows ?? result.rows);
const insertedCount = safeNumber(
 result.insertedCount ??
 result.inserted ??
 result.meta?.insertedCount ??
 0
 );
const failedCount = safeNumber(
 result.failedCount ?? result.failed ?? result.meta?.failedCount ?? 0
 );
const failedRows =
 result.failedRows ||
 result.failedRecords ||
 result.errors ||
 [];
async function handleGenerateSummary() {
 try {
 setAiLoading(true);
 setAiError("");
 const text = await generateUploadSummary({
 fileName,
 totalRows,
 insertedCount,
 failedCount,
 failedRows
 });
 setAiText(text);
 } catch (error) {
 console.error("AI summary error:", error);
 setAiError(
 "Could not generate AI summary. Please try again after some time."
 );
 } finally {
 setAiLoading(false);
 }
 }
const uploadSuccessful = failedCount === 0 && insertedCount > 0;
return (


 📊
 Upload Summary


 <p
    className={`summary-status ${
      uploadSuccessful ? "success-text" : "error-text"
    }`}
  >
    {uploadSuccessful ? "Upload completed" : "Upload completed with errors"}
  </p>

  <div className="summary-rows">
    <div className="summary-row">
      <div className="summary-label">
        <span className="summary-label-icon">📂</span>
        <span>File name</span>
      </div>
      <div className="summary-colon">:</div>
      <div className="summary-file summary-value">{fileName}</div>
    </div>

    <div className="summary-row">
      <div className="summary-label">
        <span className="summary-label-icon">📄</span>
        <span>Total rows</span>
      </div>
      <div className="summary-colon">:</div>
      <div className="summary-value">{totalRows}</div>
    </div>

    <div className="summary-row">
      <div className="summary-label">
        <span className="summary-label-icon success-dot">✔</span>
        <span>Inserted</span>
      </div>
      <div className="summary-colon">:</div>
      <div className="summary-value">{insertedCount}</div>
    </div>

    <div className="summary-row">
      <div className="summary-label">
        <span className="summary-label-icon warn-dot">!</span>
        <span>Failed</span>
      </div>
      <div className="summary-colon">:</div>
      <div className="summary-value">{failedCount}</div>
    </div>
  </div>

  <div className="ai-summary-block">
    <button
      type="button"
      className="btn-upload"
      onClick={handleGenerateSummary}
      disabled={aiLoading}
    >
      {aiLoading ? "Generating AI summary..." : "Generate AI summary"}
    </button>

    {aiError && <p className="ai-error-text">{aiError}</p>}
    {aiText && (
      <div className="ai-summary-text">
        <h3>AI Summary</h3>
        <p>{aiText}</p>
      </div>
    )}
  </div>

  {failedCount > 0 && failedRows && failedRows.length > 0 && (
    <div className="failed-table-wrapper">
      <h3 className="failed-title">Failed rows</h3>
      <div className="failed-table">
        <div className="failed-header-row">
          <div className="failed-cell-row">Row</div>
          <div className="failed-cell-reason">Reason</div>
        </div>
        {failedRows.map((err, index) => (
          <div className="failed-data-row" key={index}>
            <div className="failed-cell-row">{err.row ?? err.rowNumber}</div>
            <div className="failed-cell-reason">
              {err.reason || err.error || "Unknown error"}
            </div>
          </div>
        ))}
      </div>
    </div>
  )}
</div>

);
 }
ResponseCard.propTypes = {
 result: PropTypes.any
 };
export default ResponseCard;
