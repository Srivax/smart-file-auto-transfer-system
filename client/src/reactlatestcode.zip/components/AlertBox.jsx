import PropTypes from "prop-types";
const TYPE_CLASS = {
 info: "alert-info",
 success: "alert-success",
 warning: "alert-warning",
 error: "alert-error"
 };
function AlertBox({ type = "info", message, onClose }) {
 if (!message) return null;
const typeClass = TYPE_CLASS[type] || TYPE_CLASS.info;
return (
 <div className={alert-box ${typeClass}}>

 {type === "success" && "✅"}
 {type === "error" && "⚠️"}
 {type === "warning" && "⚠️"}
 {type === "info" && "ℹ️"}

 {message}

 ✕


 );
 }
AlertBox.propTypes = {
 type: PropTypes.string,
 message: PropTypes.string,
 onClose: PropTypes.func
 };
export default AlertBox;
