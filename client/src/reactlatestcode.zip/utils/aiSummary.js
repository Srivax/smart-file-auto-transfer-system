export async function generateUploadSummary({
fileName,
totalRows,
insertedCount,
failedCount,
failedRows
}) {
await new Promise((resolve) => setTimeout(resolve, 400));

const safeFileName = fileName || "the uploaded file";
const safeTotal = Number.isFinite(totalRows) ? totalRows : 0;
const safeInserted = Number.isFinite(insertedCount) ? insertedCount : 0;
const safeFailed = Number.isFinite(failedCount) ? failedCount : 0;

const hadFailures = safeFailed > 0 && Array.isArray(failedRows) && failedRows.length > 0;

const issuesText = hadFailures
? "Some rows failed validation. Please review the failed rows section for exact reasons and fix the data in your source sheet."
: "No validation issues were reported for this upload. All valid rows were processed successfully.";

const summaryLines = [
File "${safeFileName}" was processed by the Smart File AutoTransfer System.,
Out of ${safeTotal} total rows, ${safeInserted} were inserted and ${safeFailed} failed validation.,
issuesText,
"You can now proceed with the next upload or move to reporting / analytics in the backend."
];

return summaryLines.join(" ");
}