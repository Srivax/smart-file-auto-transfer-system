import { useEffect, useState } from "react";
 import UploadForm from "./components/UploadForm";
 import ResponseCard from "./components/ResponseCard";
 import AlertBox from "./components/AlertBox";
 import ErrorBoundary from "./components/ErrorBoundary";
 import { logClientEvent } from "./utils/logger";
function App() {
 const [selectedFile, setSelectedFile] = useState(null);
 const [result, setResult] = useState(null);
 const [isUploading, setIsUploading] = useState(false);
 const [darkMode, setDarkMode] = useState(false);
 const [alert, setAlert] = useState(null);
// Attach dark / light class to
 useEffect(() => {
 const body = document.body;
 if (darkMode) {
 body.classList.add("body-dark");
 } else {
 body.classList.remove("body-dark");
 }
 }, [darkMode]);
function showAlert(type, message) {
 setAlert({ type, message });
// Auto-dismiss after 4 seconds
if (message) {
  setTimeout(() => {
    setAlert((current) => {
      if (!current) return current;
      if (current.message !== message) return current;
      return null;
    });
  }, 4000);
}

}
function handleFileSelect(file) {
 setSelectedFile(file);
 setResult(null);
if (file) {
  logClientEvent("file_selected", { name: file.name, size: file.size });
} else {
  logClientEvent("file_cleared");
}

}
async function handleUpload() {
 if (!selectedFile) {
 showAlert("warning", "Please choose an Excel file before uploading.");
 return;
 }
try {
  setIsUploading(true);
  showAlert("info", "Uploading file. Please wait...");
  logClientEvent("upload_started", { name: selectedFile.name });

  const formData = new FormData();
  formData.append("file", selectedFile);

  // Adjust URL if your backend is different
  const response = await fetch("http://localhost:5000/api/upload", {
    method: "POST",
    body: formData
  });

  if (!response.ok) {
    const errorText = await response.text();
    logClientEvent("upload_http_error", { status: response.status, errorText });
    showAlert("error", "Upload failed. Please try again.");
    return;
  }

  const data = await response.json();
  setResult(data);

  if (data && data.failedCount > 0) {
    showAlert(
      "warning",
      `Upload finished: ${data.insertedCount ?? 0} inserted, ${data.failedCount} failed.`
    );
  } else {
    showAlert(
      "success",
      "Upload completed successfully. All valid rows were inserted."
    );
  }

  logClientEvent("upload_finished", {
    name: data.fileName,
    totalRows: data.totalRows,
    insertedCount: data.insertedCount,
    failedCount: data.failedCount
  });
} catch (error) {
  console.error("Upload error:", error);
  logClientEvent("upload_exception", { message: error.message });
  showAlert(
    "error",
    "Unexpected error while uploading. Please check the backend and try again."
  );
} finally {
  setIsUploading(false);
}

}
function handleToggleTheme() {
 setDarkMode((prev) => !prev);
 logClientEvent("theme_toggled");
 }
return (
 <div className={app ${darkMode ? "app-dark" : ""}}>


 Smart File AutoTransfer System

 Upload Excel mark sheets, validate data, and view clean upload summaries.



   <button
      type="button"
      className="theme-toggle"
      onClick={handleToggleTheme}
    >
      <span className="theme-icon">🌙</span>
      <span className="theme-text">{darkMode ? "Light mode" : "Dark mode"}</span>
    </button>
  </header>

  {alert && (
    <div className="alert-container">
      <AlertBox
        type={alert.type}
        message={alert.message}
        onClose={() => setAlert(null)}
      />
    </div>
  )}

  <main className="main-shell">
    <section className="upload-section">
      <div className="upload-card">
        <ErrorBoundary>
          <UploadForm
            selectedFile={selectedFile}
            onFileSelect={handleFileSelect}
            onUpload={handleUpload}
            isUploading={isUploading}
            showAlert={showAlert}
          />
        </ErrorBoundary>
      </div>
    </section>

    <section className="summary-section">
      <div className="summary-card">
        <ErrorBoundary>
          <ResponseCard result={result} />
        </ErrorBoundary>
      </div>
    </section>
  </main>
</div>

);
 }
export default App;
