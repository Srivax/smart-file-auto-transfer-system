export async function buildAISummary({
  fileName,
  totalRows,
  inserted,
  failed
}) {
  await new Promise((resolve) => setTimeout(resolve, 300));

  const safeName = fileName || "the uploaded file";
  const total = typeof totalRows === "number" ? totalRows : 0;
  const ok = typeof inserted === "number" ? inserted : 0;
  const bad = typeof failed === "number" ? failed : 0;

  let qualityText;
  if (total === 0) {
    qualityText = "No usable rows were found in this upload.";
  } else if (bad === 0) {
    qualityText = "All rows passed validation. The data quality for this upload is very high.";
  } else if (bad <= Math.round(total * 0.1)) {
    qualityText =
      "Most rows passed validation. Only a small portion of the data needs correction before the next upload.";
  } else {
    qualityText =
      "A significant number of rows failed validation. It is recommended to review the original sheet carefully and fix the highlighted issues.";
  }

  const lines = [
    `File "${safeName}" was processed by the Smart File AutoTransfer System.`,
    `Out of ${total} total rows, ${ok} were inserted successfully and ${bad} failed validation.`,
    qualityText,
    "After applying corrections, you can upload a revised sheet to keep the database clean and reliable."
  ];

  return lines.join(" ");
}
